import React from 'react'
import { View, Text } from 'react-native';

const AccountSettings = () => {
    return (
        <>
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                <Text>Account Setting Screen</Text>
            </View>

        </>
    )
}

export default AccountSettings;
